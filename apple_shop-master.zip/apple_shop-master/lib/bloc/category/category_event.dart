part of 'category_bloc.dart';

abstract class CategoryEvent {}

class CategoryRequestLoaded extends CategoryEvent {}
