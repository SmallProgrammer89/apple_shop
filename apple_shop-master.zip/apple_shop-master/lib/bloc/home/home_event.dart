part of 'home_bloc.dart';

abstract class HomeEvent {}

class HomeGetRequestedEvent extends HomeEvent {}
