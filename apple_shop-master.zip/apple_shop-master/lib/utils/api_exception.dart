class ApiException {
  int? code;
  String? message;
  ApiException(this.code, this.message);
}
